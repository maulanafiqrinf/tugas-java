/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package penjualan;

/**
 *
 * @author user
 */
public class Penjualan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        UIPenjualan penjualan = new UIPenjualan();
        penjualan.setVisible(true);
    }
}
